# Interactive Lab Guide

This package keeps the fully automated thesis tests and adds an interactive menu.

## Main commands

```bash
./scripts/start_lab.sh
./scripts/interactive_attack_lab.sh
```

Menu option **4** lets you run any single thesis test from 5.6.1 to 5.6.6.

Menu option **5** now runs the **complete guided walkthrough**:

- Scenario A: 5.6.1, 5.6.2, 5.6.3, 5.6.4, 5.6.5.
- Scenario A: 5.6.6 is explicitly shown as N/A because the traditional VLAN model has no ticket lifecycle control.
- Scenario B: 5.6.1, 5.6.2, 5.6.3, 5.6.4, 5.6.5, 5.6.6.

This matches the thesis design and the automated suite:

```bash
./scripts/run_ch5_revised_suite.sh a
./scripts/run_ch5_revised_suite.sh b
```

Use the guided walkthrough for screenshots and explanation. Use the automated suite for final result files.
