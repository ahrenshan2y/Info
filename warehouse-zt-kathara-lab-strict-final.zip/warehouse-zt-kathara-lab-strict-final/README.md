# Smart Warehouse Strict Zero-Trust Kathara Lab

Final Kathara experiment package matching the thesis Chapter 5 and Chapter 6.

It compares:
- Scenario A: traditional VLAN segmentation
- Scenario B: strict zero-trust enhanced model

## Compatibility fixes included
1. Device names use underscores, not hyphens.
2. Scripts use `kathara exec`, not `kathara connect --command`.
3. Helper functions `msg`, `ok`, and `warn` are defined in `scripts/_common.sh`.
4. `ip_forward` initialization is silent and non-fatal to avoid the previous visible sysctl warning.
5. Strict zero-trust rules are applied both on `core` and on key endpoints, so same-subnet east-west traffic is also controlled.

## Network zones
| Zone | Prefix | Nodes |
|---|---|---|
| Office Net | 10.10.10.0/24 | office_client, pda_client |
| Guest Net | 10.10.20.0/24 | guest_client, attacker_node |
| CCTV Net | 10.10.30.0/24 | camera1, camera2, nvr_server |
| Management Net | 10.10.40.0/24 | mgmt_admin, thirdparty_maint, infra_mgmt |
| Business Service Zone | 10.10.50.0/24 | wms_app |
| Control/Policy Zone | 10.10.60.0/24 | policy_node |
| Simulated Internet Zone | 172.16.0.0/24 | internet |

## Run inside Ubuntu/WSL
```bash
cd warehouse-zt-kathara-lab-strict-final
chmod +x scripts/*.sh
sed -i 's/\r$//' scripts/*.sh *.startup
./scripts/start_lab.sh
./scripts/run_ch5_revised_suite.sh a
./scripts/run_ch5_revised_suite.sh b
ls results
./scripts/stop_lab.sh
```

If Docker permissions require sudo, set `K="sudo kathara"` in `scripts/_common.sh` and also use sudo in `scripts/start_lab.sh` and `scripts/stop_lab.sh`.

Expected results are documented in `EXPECTED_RESULTS.md`.

## Semi-interactive experiment mode

This version also includes an interactive demonstration menu:

```bash
./scripts/start_lab.sh
./scripts/interactive_attack_lab.sh
```

Use it to:
- apply Scenario A or Scenario B step by step;
- open a shell inside a node, e.g. `camera1` or `pda_client`;
- manually probe access paths with ping;
- run one thesis test at a time;
- run a guided walkthrough with pauses for screenshots.

See `INTERACTIVE_LAB_GUIDE.md` for a suggested screenshot workflow.

## Interactive complete guided walkthrough

The interactive menu includes a complete guided walkthrough aligned with thesis section 5.6:

```bash
./scripts/interactive_attack_lab.sh
```

Choose option `5` to run the complete walkthrough with pauses. It runs Scenario A tests 5.6.1-5.6.5, marks 5.6.6 as N/A for Scenario A, then runs Scenario B tests 5.6.1-5.6.6.
