# Expected Results for Chapter 5/6 Strict Zero-Trust Lab

## Scenario A: Traditional VLAN Segmentation
- 5.6.1: camera1_to_camera2=ALLOW; camera1_to_office=ALLOW; camera1_to_mgmt=ALLOW
- 5.6.2: office_to_infra_mgmt=ALLOW; office_to_nvr=ALLOW
- 5.6.3: thirdparty_to_infra_mgmt_without_ticket=ALLOW; thirdparty_to_nvr_without_ticket=ALLOW
- 5.6.4: pda_to_wms=ALLOW; pda_to_office=ALLOW; pda_to_nvr=ALLOW; pda_to_infra_mgmt=ALLOW
- 5.6.5: unmanaged_device_with_admin_creds_to_infra_mgmt=ALLOW; managed_admin_device_to_infra_mgmt=ALLOW
- 5.6.6: skipped in Scenario A

## Scenario B: Strict Zero-Trust
- 5.6.1: camera1_to_camera2=DENY; camera1_to_office=DENY; camera1_to_mgmt=DENY
- 5.6.2: office_to_infra_mgmt=DENY; office_to_nvr=DENY
- 5.6.3: thirdparty_to_infra_mgmt_without_ticket=DENY; thirdparty_to_nvr=DENY
- 5.6.4: pda_to_wms=ALLOW; pda_to_office=DENY; pda_to_nvr=DENY; pda_to_infra_mgmt=DENY
- 5.6.5: unmanaged_device_with_admin_creds_to_infra_mgmt=DENY; managed_admin_device_to_infra_mgmt=ALLOW
- 5.6.6: ticket active=ALLOW; ticket expired=DENY
