#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/lateral-$TS.txt"
{
  echo "=== Lateral movement quick check ==="
  echo "Scenario time: $(date)"
  echo
  echo "[1] camera1 -> camera2"
  if run_in camera1 'ping -c 1 -W 1 10.10.30.12 >/dev/null 2>&1'; then echo "ALLOW"; else echo "DENY"; fi
  echo
  echo "[2] camera1 -> infra_mgmt"
  if run_in camera1 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then echo "ALLOW"; else echo "DENY"; fi
  echo
  echo "[3] office_client -> infra_mgmt"
  if run_in office_client 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then echo "ALLOW"; else echo "DENY"; fi
  echo
  echo "[4] attacker_node -> wms_app"
  if run_in attacker_node 'ping -c 1 -W 1 10.10.50.10 >/dev/null 2>&1'; then echo "ALLOW"; else echo "DENY"; fi
} | tee "$OUT_FILE"
msg "Saved lateral results to $OUT_FILE"
