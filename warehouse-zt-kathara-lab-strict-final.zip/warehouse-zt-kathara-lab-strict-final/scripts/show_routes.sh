#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
for n in core office_client guest_client pda_client camera1 camera2 nvr_server mgmt_admin thirdparty_maint infra_mgmt wms_app policy_node internet attacker_node; do
  echo "===== $n ====="
  run_in "$n" 'ip -br addr; echo; ip route' || true
  echo
done
