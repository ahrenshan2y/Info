#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
"$(dirname "$0")/reset_firewalls.sh"
msg "Applying Scenario B (strict zero-trust enhanced)"

# CORE: default deny. Only explicitly approved cross-subnet business flows are allowed.
run_in core 'iptables -P FORWARD DROP; \
  iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A FORWARD -s 10.10.20.0/24 -d 172.16.0.100 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.10.10 -d 10.10.50.10 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.10.10 -d 172.16.0.100 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.10.20 -d 10.10.50.10 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.40.10 -d 10.10.30.100 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.40.10 -d 10.10.50.10 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.40.10 -d 10.10.60.10 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.40.10 -d 172.16.0.100 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.30.11 -d 10.10.60.10 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.30.12 -d 10.10.60.10 -j ACCEPT; \
  iptables -A FORWARD -s 10.10.60.10 -d 10.10.0.0/16 -j ACCEPT'

# WMS endpoint: only Office, PDA, authorized management, and policy plane.
run_in wms_app 'iptables -P INPUT DROP; \
  iptables -A INPUT -i lo -j ACCEPT; \
  iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A INPUT -s 10.10.10.10 -j ACCEPT; \
  iptables -A INPUT -s 10.10.10.20 -j ACCEPT; \
  iptables -A INPUT -s 10.10.40.10 -j ACCEPT; \
  iptables -A INPUT -s 10.10.60.10 -j ACCEPT'

# Infra management endpoint: only trusted managed admin and policy plane by default.
# Third-party maintenance is NOT allowed until a ticket is enabled.
run_in infra_mgmt 'iptables -P INPUT DROP; \
  iptables -A INPUT -i lo -j ACCEPT; \
  iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A INPUT -s 10.10.40.10 -j ACCEPT; \
  iptables -A INPUT -s 10.10.60.10 -j ACCEPT'

# NVR endpoint: cameras, trusted managed admin, and policy plane. Third-party only with ticket.
run_in nvr_server 'iptables -P INPUT DROP; \
  iptables -A INPUT -i lo -j ACCEPT; \
  iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A INPUT -s 10.10.30.11 -j ACCEPT; \
  iptables -A INPUT -s 10.10.30.12 -j ACCEPT; \
  iptables -A INPUT -s 10.10.40.10 -j ACCEPT; \
  iptables -A INPUT -s 10.10.60.10 -j ACCEPT'

# Strict endpoint egress policies, needed because several nodes share the same subnet
# and same-subnet traffic bypasses the core FORWARD chain.
run_in office_client 'iptables -P OUTPUT DROP; \
  iptables -A OUTPUT -o lo -j ACCEPT; \
  iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A OUTPUT -d 10.10.50.10 -j ACCEPT; \
  iptables -A OUTPUT -d 172.16.0.100 -j ACCEPT'

run_in pda_client 'iptables -P OUTPUT DROP; \
  iptables -A OUTPUT -o lo -j ACCEPT; \
  iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A OUTPUT -d 10.10.50.10 -j ACCEPT'

for cam in camera1 camera2; do
  run_in "$cam" 'iptables -P OUTPUT DROP; \
    iptables -A OUTPUT -o lo -j ACCEPT; \
    iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
    iptables -A OUTPUT -d 10.10.30.100 -j ACCEPT; \
    iptables -A OUTPUT -d 10.10.60.10 -j ACCEPT'
done

run_in mgmt_admin 'iptables -P OUTPUT DROP; \
  iptables -A OUTPUT -o lo -j ACCEPT; \
  iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT; \
  iptables -A OUTPUT -d 10.10.40.254 -j ACCEPT; \
  iptables -A OUTPUT -d 10.10.30.100 -j ACCEPT; \
  iptables -A OUTPUT -d 10.10.50.10 -j ACCEPT; \
  iptables -A OUTPUT -d 10.10.60.10 -j ACCEPT; \
  iptables -A OUTPUT -d 172.16.0.100 -j ACCEPT'

# Third-party maintenance device: default deny. Ticket scripts temporarily open only approved targets.
run_in thirdparty_maint 'iptables -P OUTPUT DROP; \
  iptables -A OUTPUT -o lo -j ACCEPT; \
  iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT'

# Keep policy-node able to initiate checks/telemetry.
run_in policy_node 'iptables -P OUTPUT ACCEPT'

msg "Scenario B strict zero-trust applied"
