#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/5.6.2-office-to-mgmt-$TS.txt"

{
  echo "test,result"
  printf 'office_to_infra_mgmt,'
  if run_in office_client 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then echo 'ALLOW'; else echo 'DENY'; fi
  printf 'office_to_nvr,'
  if run_in office_client 'ping -c 1 -W 1 10.10.30.100 >/dev/null 2>&1'; then echo 'ALLOW'; else echo 'DENY'; fi
} | tee "$OUT_FILE"
msg "Saved 5.6.2 results to $OUT_FILE"
