#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/5.6.5-stolen-admin-creds-unmanaged-$TS.txt"

# Simulated by using thirdparty_maint as an unmanaged device with supposed valid creds.
{
  echo "test,result"
  printf 'unmanaged_device_with_admin_creds_to_infra_mgmt,'
  if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then echo 'ALLOW'; else echo 'DENY'; fi
  printf 'managed_admin_device_to_infra_mgmt,'
  if run_in mgmt_admin 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then echo 'ALLOW'; else echo 'DENY'; fi
} | tee "$OUT_FILE"
msg "Saved 5.6.5 results to $OUT_FILE"
