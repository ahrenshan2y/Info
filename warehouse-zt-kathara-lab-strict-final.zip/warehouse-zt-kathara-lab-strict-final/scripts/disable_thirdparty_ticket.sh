#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
msg "Revoking temporary ticketed maintenance access from thirdparty_maint"
run_in thirdparty_maint 'while iptables -D OUTPUT -d 10.10.40.254 -j ACCEPT 2>/dev/null; do :; done; while iptables -D OUTPUT -d 10.10.30.100 -j ACCEPT 2>/dev/null; do :; done; true'
run_in infra_mgmt 'while iptables -D INPUT -s 10.10.40.20 -j ACCEPT 2>/dev/null; do :; done; true'
run_in nvr_server 'while iptables -D INPUT -s 10.10.40.20 -j ACCEPT 2>/dev/null; do :; done; true'
run_in core 'while iptables -D FORWARD -s 10.10.40.20 -d 10.10.30.100 -j ACCEPT 2>/dev/null; do :; done; true'
msg "Temporary maintenance ticket revoked"
