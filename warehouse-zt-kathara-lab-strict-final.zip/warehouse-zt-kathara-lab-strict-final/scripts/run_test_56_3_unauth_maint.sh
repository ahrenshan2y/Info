#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/5.6.3-unauth-maint-$TS.txt"

{
  echo "test,result"
  printf 'thirdparty_to_infra_mgmt_without_ticket,'
  if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then echo 'ALLOW'; else echo 'DENY'; fi
  printf 'thirdparty_to_nvr_without_ticket,'
  if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.30.100 >/dev/null 2>&1'; then echo 'ALLOW'; else echo 'DENY'; fi
} | tee "$OUT_FILE"
msg "Saved 5.6.3 results to $OUT_FILE"
