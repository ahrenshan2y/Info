#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
"$(dirname "$0")/reset_firewalls.sh"
msg "Applying Scenario A (traditional VLAN segmentation)"
# Core router: allow everything except Guest -> internal zones
run_in core 'iptables -P FORWARD ACCEPT; \
  iptables -A FORWARD -s 10.10.20.0/24 -d 10.10.10.0/24 -j REJECT; \
  iptables -A FORWARD -s 10.10.20.0/24 -d 10.10.30.0/24 -j REJECT; \
  iptables -A FORWARD -s 10.10.20.0/24 -d 10.10.40.0/24 -j REJECT; \
  iptables -A FORWARD -s 10.10.20.0/24 -d 10.10.50.0/24 -j REJECT; \
  iptables -A FORWARD -s 10.10.20.0/24 -d 10.10.60.0/24 -j REJECT'
msg "Scenario A applied"
