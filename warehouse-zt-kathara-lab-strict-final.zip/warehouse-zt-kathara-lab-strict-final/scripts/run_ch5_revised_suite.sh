#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
SCENARIO="${1:-b}"
case "$SCENARIO" in
  a|A) "$(dirname "$0")/apply_scenario_a.sh" ;;
  b|B) "$(dirname "$0")/apply_scenario_b.sh" ;;
  *) echo "Usage: $0 [a|b]"; exit 1 ;;
esac
"$(dirname "$0")/run_test_56_1_cctv_lateral.sh"
"$(dirname "$0")/run_test_56_2_office_to_mgmt.sh"
"$(dirname "$0")/run_test_56_3_unauth_maint.sh"
"$(dirname "$0")/run_test_56_4_compromised_pda.sh"
"$(dirname "$0")/run_test_56_5_stolen_admin_creds_unmanaged.sh"
if [[ "$SCENARIO" =~ ^[bB]$ ]]; then
  "$(dirname "$0")/run_test_56_6_expired_ticket.sh"
else
  echo "Skipping 5.6.6 expired ticket lifecycle test in Scenario A (not meaningful without ticketed access model)."
fi
msg "Chapter 5 revised suite completed for scenario $SCENARIO"
