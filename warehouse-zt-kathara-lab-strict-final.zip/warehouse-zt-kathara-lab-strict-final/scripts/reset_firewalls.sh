#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
for dev in core wms_app nvr_server infra_mgmt camera1 camera2 office_client guest_client pda_client mgmt_admin thirdparty_maint attacker_node internet policy_node; do
  msg "Resetting firewall on $dev"
  run_in "$dev" 'if command -v iptables >/dev/null 2>&1; then iptables -F; iptables -X; iptables -t nat -F; iptables -t nat -X; iptables -P INPUT ACCEPT; iptables -P FORWARD ACCEPT; iptables -P OUTPUT ACCEPT; fi'
done
# Re-enable forwarding on core when permitted. Some Docker/Kathara versions deny this sysctl inside containers;
# in that case the lab can still run if forwarding was already enabled by startup/runtime.
run_in core 'sysctl -w net.ipv4.ip_forward=1 >/dev/null 2>&1 || true'
