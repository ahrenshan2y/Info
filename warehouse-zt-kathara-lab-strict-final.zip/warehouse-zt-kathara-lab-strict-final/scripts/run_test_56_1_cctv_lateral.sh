#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/5.6.1-cctv-lateral-$TS.txt"

check() {
  local label="$1" cmd="$2"
  printf '%s,' "$label" >> "$OUT_FILE"
  if eval "$cmd"; then echo 'ALLOW' | tee -a "$OUT_FILE"; else echo 'DENY' | tee -a "$OUT_FILE"; fi
}

{
  echo "test,expected_interpretation"
  echo "camera1_to_camera2,Compromised CCTV node lateral scan inside CCTV VLAN"
  echo "camera1_to_office,Compromised CCTV node probes Office VLAN"
  echo "camera1_to_mgmt,Compromised CCTV node probes Management VLAN"
} > "$OUT_FILE"

check "camera1_to_camera2" "run_in camera1 'ping -c 1 -W 1 10.10.30.12 >/dev/null 2>&1'"
check "camera1_to_office" "run_in camera1 'ping -c 1 -W 1 10.10.10.10 >/dev/null 2>&1'"
check "camera1_to_mgmt" "run_in camera1 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'"
msg "Saved 5.6.1 results to $OUT_FILE"
