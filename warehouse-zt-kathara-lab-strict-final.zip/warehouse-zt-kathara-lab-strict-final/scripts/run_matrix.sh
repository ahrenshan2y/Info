#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/matrix-$TS.csv"
echo 'source,target,target_ip,result' > "$OUT_FILE"

test_ping() {
  local src="$1" tgt="$2" ip="$3"
  if run_in "$src" "ping -c 1 -W 1 $ip >/dev/null 2>&1"; then
    echo "$src,$tgt,$ip,ALLOW" | tee -a "$OUT_FILE"
  else
    echo "$src,$tgt,$ip,DENY" | tee -a "$OUT_FILE"
  fi
}

# Core business tests
for spec in \
  'office_client wms_app 10.10.50.10' \
  'office_client infra_mgmt 10.10.40.254' \
  'office_client nvr_server 10.10.30.100' \
  'office_client internet 172.16.0.100' \
  'guest_client wms_app 10.10.50.10' \
  'guest_client infra_mgmt 10.10.40.254' \
  'guest_client nvr_server 10.10.30.100' \
  'guest_client internet 172.16.0.100' \
  'pda_client wms_app 10.10.50.10' \
  'pda_client infra_mgmt 10.10.40.254' \
  'pda_client nvr_server 10.10.30.100' \
  'pda_client internet 172.16.0.100' \
  'camera1 nvr_server 10.10.30.100' \
  'camera1 camera2 10.10.30.12' \
  'camera1 wms_app 10.10.50.10' \
  'camera1 infra_mgmt 10.10.40.254' \
  'mgmt_admin infra_mgmt 10.10.40.254' \
  'mgmt_admin nvr_server 10.10.30.100' \
  'mgmt_admin wms_app 10.10.50.10' \
  'thirdparty_maint infra_mgmt 10.10.40.254' \
  'thirdparty_maint nvr_server 10.10.30.100' \
  'attacker_node wms_app 10.10.50.10' \
  'attacker_node infra_mgmt 10.10.40.254' \
  'attacker_node internet 172.16.0.100'; do
  test_ping $spec
done

echo
msg "Saved matrix results to $OUT_FILE"
