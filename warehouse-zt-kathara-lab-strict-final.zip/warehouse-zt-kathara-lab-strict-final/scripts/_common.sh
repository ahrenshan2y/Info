#!/usr/bin/env bash
set -euo pipefail
LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
K="kathara"
msg() { echo "[*] $*"; }
ok() { echo "[+] $*"; }
warn() { echo "[!] $*"; }
run_in() {
  local dev="$1"; shift
  local cmd="$*"
  $K exec -d "$LAB_DIR" "$dev" -- sh -lc "$cmd"
}
