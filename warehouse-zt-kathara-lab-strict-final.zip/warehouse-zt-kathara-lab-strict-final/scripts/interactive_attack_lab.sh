#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"

NODES=(core office_client guest_client pda_client camera1 camera2 nvr_server mgmt_admin thirdparty_maint infra_mgmt wms_app policy_node internet attacker_node)

divider() { printf '\n%s\n' "------------------------------------------------------------"; }
wait_key() { printf '\nPress ENTER to continue...'; read -r _ || true; }

list_nodes() {
  echo "Available nodes:"
  local i=1
  for n in "${NODES[@]}"; do printf "  %2d) %s\n" "$i" "$n"; i=$((i+1)); done
}

valid_node() {
  local n="$1"
  for x in "${NODES[@]}"; do [[ "$x" == "$n" ]] && return 0; done
  return 1
}

open_shell() {
  list_nodes
  printf "Enter node name to open interactive shell: "
  read -r node
  if ! valid_node "$node"; then echo "Invalid node: $node"; return 1; fi
  echo "Opening $node. Type 'exit' to return to the menu."
  $K connect -d "$LAB_DIR" "$node"
}

probe_once() {
  list_nodes
  printf "Source node: "; read -r src
  if ! valid_node "$src"; then echo "Invalid source: $src"; return 1; fi
  cat <<'IPLIST'
Common target IPs:
  office_client      10.10.10.10
  pda_client         10.10.10.20
  guest_client       10.10.20.10
  attacker_node      10.10.20.66
  camera1            10.10.30.11
  camera2            10.10.30.12
  nvr_server         10.10.30.100
  mgmt_admin         10.10.40.10
  thirdparty_maint   10.10.40.20
  infra_mgmt         10.10.40.254
  wms_app            10.10.50.10
  policy_node        10.10.60.10
  internet           172.16.0.100
IPLIST
  printf "Target IP: "; read -r ip
  echo "Running: $src -> $ip"
  if run_in "$src" "ping -c 1 -W 1 $ip >/dev/null 2>&1"; then
    echo "RESULT: ALLOW"
  else
    echo "RESULT: DENY"
  fi
}

run_one_test() {
  cat <<'TESTS'
Choose a test:
  1) 5.6.1 CCTV lateral scan
  2) 5.6.2 Office terminal to Management/NVR
  3) 5.6.3 Unauthorized third-party maintenance
  4) 5.6.4 Compromised PDA
  5) 5.6.5 Stolen admin credentials from unmanaged device
  6) 5.6.6 Expired third-party ticket lifecycle
TESTS
  printf "Test number: "; read -r t
  case "$t" in
    1) "$LAB_DIR/scripts/run_test_56_1_cctv_lateral.sh" ;;
    2) "$LAB_DIR/scripts/run_test_56_2_office_to_mgmt.sh" ;;
    3) "$LAB_DIR/scripts/run_test_56_3_unauth_maint.sh" ;;
    4) "$LAB_DIR/scripts/run_test_56_4_compromised_pda.sh" ;;
    5) "$LAB_DIR/scripts/run_test_56_5_stolen_admin_creds_unmanaged.sh" ;;
    6) "$LAB_DIR/scripts/run_test_56_6_expired_ticket.sh" ;;
    *) echo "Invalid test" ;;
  esac
}

latest_results() {
  echo "Latest result files:"
  ls -lt "$LAB_DIR/results" | head -20 || true
  printf "Open latest file? [y/N]: "
  read -r yn
  if [[ "$yn" =~ ^[Yy]$ ]]; then
    f=$(ls -t "$LAB_DIR/results"/* 2>/dev/null | head -1 || true)
    if [[ -n "${f:-}" ]]; then echo "===== $f ====="; cat "$f"; else echo "No result files yet."; fi
  fi
}

walkthrough() {
  divider
  echo "Interactive guided attack walkthrough - COMPLETE THESIS TEST SET"
  echo "This walkthrough follows the final thesis section 5.6."
  echo "Scenario A runs 5.6.1-5.6.5. Test 5.6.6 is explained as N/A in Scenario A because there is no ticket lifecycle model."
  echo "Scenario B runs 5.6.1-5.6.6."
  wait_key

  divider
  echo "PART I - Scenario A: Traditional VLAN segmentation"
  echo "Applying Scenario A..."
  "$LAB_DIR/scripts/apply_scenario_a.sh"
  wait_key

  divider
  echo "A / Test 5.6.1 - Compromised CCTV node lateral scan"
  "$LAB_DIR/scripts/run_test_56_1_cctv_lateral.sh"
  echo "Thesis interpretation: in the traditional model, compromised CCTV can usually keep broad internal reachability."
  wait_key

  divider
  echo "A / Test 5.6.2 - Office endpoint attempts Management/NVR access"
  "$LAB_DIR/scripts/run_test_56_2_office_to_mgmt.sh"
  echo "Thesis interpretation: the office endpoint may reach high-sensitivity resources under broad internal trust."
  wait_key

  divider
  echo "A / Test 5.6.3 - Unauthorized third-party maintenance access"
  "$LAB_DIR/scripts/run_test_56_3_unauth_maint.sh"
  echo "Thesis interpretation: network position may be confused with maintenance authorization."
  wait_key

  divider
  echo "A / Test 5.6.4 - Compromised PDA attempts non-business access"
  "$LAB_DIR/scripts/run_test_56_4_compromised_pda.sh"
  echo "Thesis interpretation: the PDA business path is preserved, but non-business reachability may remain too wide."
  wait_key

  divider
  echo "A / Test 5.6.5 - Stolen admin credentials from unmanaged device"
  "$LAB_DIR/scripts/run_test_56_5_stolen_admin_creds_unmanaged.sh"
  echo "Thesis interpretation: a traditional model may rely too heavily on credentials and network position."
  wait_key

  divider
  echo "A / Test 5.6.6 - Expired third-party ticket lifecycle"
  echo "SKIPPED / N/A for Scenario A."
  echo "Reason: the traditional VLAN model does not implement a ticket-bound temporary authorization lifecycle."
  echo "This matches the automated suite: Scenario A skips 5.6.6."
  wait_key

  divider
  echo "PART II - Scenario B: Strict Zero-Trust"
  echo "Applying Scenario B..."
  "$LAB_DIR/scripts/apply_scenario_b.sh"
  wait_key

  divider
  echo "B / Test 5.6.1 - Compromised CCTV node lateral scan"
  "$LAB_DIR/scripts/run_test_56_1_cctv_lateral.sh"
  echo "Expected thesis interpretation: CCTV lateral movement is denied by endpoint and core enforcement."
  wait_key

  divider
  echo "B / Test 5.6.2 - Office endpoint attempts Management/NVR access"
  "$LAB_DIR/scripts/run_test_56_2_office_to_mgmt.sh"
  echo "Expected thesis interpretation: office-to-management and office-to-NVR unauthorized paths are denied."
  wait_key

  divider
  echo "B / Test 5.6.3 - Unauthorized third-party maintenance access"
  "$LAB_DIR/scripts/run_test_56_3_unauth_maint.sh"
  echo "Expected thesis interpretation: third-party maintenance has no high-sensitivity access without a ticket."
  wait_key

  divider
  echo "B / Test 5.6.4 - Compromised PDA attempts non-business access"
  "$LAB_DIR/scripts/run_test_56_4_compromised_pda.sh"
  echo "Expected thesis interpretation: PDA-to-WMS remains allowed, while non-business paths are denied."
  wait_key

  divider
  echo "B / Test 5.6.5 - Stolen admin credentials from unmanaged device"
  "$LAB_DIR/scripts/run_test_56_5_stolen_admin_creds_unmanaged.sh"
  echo "Expected thesis interpretation: managed admin access is allowed, unmanaged credential use is denied."
  wait_key

  divider
  echo "B / Test 5.6.6 - Third-party ticket lifecycle"
  "$LAB_DIR/scripts/run_test_56_6_expired_ticket.sh"
  echo "Expected thesis interpretation: ticket-valid access is allowed and post-expiry access is denied."
  wait_key

  divider
  echo "Complete walkthrough finished. Result files are in: $LAB_DIR/results"
  echo "Suggested screenshots: this menu, A/B result outputs for each test, and the final results directory listing."
}

manual_commands() {
  cat <<EOF_CMDS
Manual interactive examples for screenshots:

1) Open the compromised camera shell:
   kathara connect -d "$LAB_DIR" camera1
   ping -c 1 10.10.30.12     # camera1 -> camera2
   ping -c 1 10.10.10.10     # camera1 -> office_client
   ping -c 1 10.10.40.254    # camera1 -> infra_mgmt
   exit

2) Open the PDA shell:
   kathara connect -d "$LAB_DIR" pda_client
   ping -c 1 10.10.50.10     # pda_client -> wms_app
   ping -c 1 10.10.10.10     # pda_client -> office_client
   ping -c 1 10.10.30.100    # pda_client -> nvr_server
   ping -c 1 10.10.40.254    # pda_client -> infra_mgmt
   exit

3) Open the third-party maintenance shell:
   kathara connect -d "$LAB_DIR" thirdparty_maint
   ping -c 1 10.10.40.254    # thirdparty_maint -> infra_mgmt
   ping -c 1 10.10.30.100    # thirdparty_maint -> nvr_server
   exit

Before trying these, apply one model:
   ./scripts/apply_scenario_a.sh
   # or
   ./scripts/apply_scenario_b.sh
EOF_CMDS
}

while true; do
  divider
  echo "Smart Warehouse Zero-Trust Interactive Lab"
  echo "LAB_DIR=$LAB_DIR"
  cat <<'MENU'
  1) Show node routes/interfaces
  2) Apply Scenario A - traditional VLAN segmentation
  3) Apply Scenario B - strict zero-trust
  4) Run one thesis test interactively
  5) Run guided attack walkthrough with pauses
  6) Manual probe: choose source node and target IP
  7) Open interactive shell in a node
  8) Enable third-party maintenance ticket
  9) Disable third-party maintenance ticket
 10) Show latest result files
 11) Print manual screenshot commands
  0) Exit menu
MENU
  printf "Choice: "
  read -r choice
  case "$choice" in
    1) "$LAB_DIR/scripts/show_routes.sh" ;;
    2) "$LAB_DIR/scripts/apply_scenario_a.sh" ;;
    3) "$LAB_DIR/scripts/apply_scenario_b.sh" ;;
    4) run_one_test ;;
    5) walkthrough ;;
    6) probe_once ;;
    7) open_shell ;;
    8) "$LAB_DIR/scripts/enable_thirdparty_ticket.sh" ;;
    9) "$LAB_DIR/scripts/disable_thirdparty_ticket.sh" ;;
    10) latest_results ;;
    11) manual_commands ;;
    0) exit 0 ;;
    *) echo "Invalid choice" ;;
  esac
  wait_key
done
