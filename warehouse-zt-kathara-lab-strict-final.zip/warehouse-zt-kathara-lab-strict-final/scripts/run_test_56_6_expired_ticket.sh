#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
OUT_DIR="$LAB_DIR/results"
mkdir -p "$OUT_DIR"
TS="$(date +%Y%m%d-%H%M%S)"
OUT_FILE="$OUT_DIR/5.6.6-expired-ticket-$TS.txt"

"$(dirname "$0")/enable_thirdparty_ticket.sh" >/dev/null
BEFORE_INFRA="DENY"
BEFORE_NVR="DENY"
if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then BEFORE_INFRA="ALLOW"; fi
if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.30.100 >/dev/null 2>&1'; then BEFORE_NVR="ALLOW"; fi
"$(dirname "$0")/disable_thirdparty_ticket.sh" >/dev/null
AFTER_INFRA="DENY"
AFTER_NVR="DENY"
if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.40.254 >/dev/null 2>&1'; then AFTER_INFRA="ALLOW"; fi
if run_in thirdparty_maint 'ping -c 1 -W 1 10.10.30.100 >/dev/null 2>&1'; then AFTER_NVR="ALLOW"; fi

{
  echo "test,pre_expiry,post_expiry"
  echo "thirdparty_to_infra_mgmt,$BEFORE_INFRA,$AFTER_INFRA"
  echo "thirdparty_to_nvr,$BEFORE_NVR,$AFTER_NVR"
} | tee "$OUT_FILE"
msg "Saved 5.6.6 results to $OUT_FILE"
