#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/_common.sh"
msg "Granting temporary ticketed maintenance access to thirdparty_maint"
# Allow third-party endpoint egress to the approved maintenance targets.
run_in thirdparty_maint 'iptables -I OUTPUT 1 -d 10.10.40.254 -j ACCEPT; iptables -I OUTPUT 1 -d 10.10.30.100 -j ACCEPT'
# Allow target resources to accept traffic from the third-party maintenance endpoint.
run_in infra_mgmt 'iptables -I INPUT 1 -s 10.10.40.20 -j ACCEPT'
run_in nvr_server 'iptables -I INPUT 1 -s 10.10.40.20 -j ACCEPT'
# Allow cross-subnet traffic to NVR during the ticket window.
run_in core 'iptables -I FORWARD 1 -s 10.10.40.20 -d 10.10.30.100 -j ACCEPT'
msg "Temporary maintenance ticket enabled"
